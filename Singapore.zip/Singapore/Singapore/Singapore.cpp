/*
Name: Waluigi wAH
Date: 08.28.2018
Description: It's Singapore
*/

#include <iostream>
#include <fstream>
#include <iomanip>
#include <windows.h>

using namespace std;


int main()
{
	//variables
	ifstream infile;
	ofstream outfile;
	string about;
	double SGD = 0.0;
	double USA = 0.0;
	double Yuan = 0.0;
	double Pound = 0.0;
	double Ruble = 0.0;
	double Yen = 0.0;

	//open files
	infile.open("C:/Users/apowers987/Desktop/SGD.txt");
	outfile.open("C:/Users/apowers987/Desktop/SGD.out");



	infile >> SGD;

	//Conversion Rates are here
	USA = (SGD * 0.73);
	Ruble = (SGD * 49.53);
	Yuan = (SGD * 5.00);
	Pound = (SGD * 0.57);
	Yen = (SGD * 81.57);

	
	//outputting Conversions
	outfile << "The amount in US dollars is " << setprecision(2) << fixed << USA << endl;
	outfile << "The amount in Russian Rubles is " << setprecision(2) << fixed << Ruble << endl;
	outfile << "The amount in Chinese yuan is " << setprecision(2) << fixed << Yuan << endl;
	outfile << "The amount in British pounds is " << setprecision(2) << fixed << Pound << endl;
	outfile << "The amount in Japanese Yens is " << setprecision(2) << fixed << Yen << endl;

	//making the flag
	outfile << "_________________________________________________________________________" << endl;
	outfile << "|             ------        ^                                            |" << endl;
	outfile << "|            /   /        < * >                                          |" << endl;
	outfile << "|           /   /   ^       \/     ^                                     |" << endl;
	outfile << "|          /   /  < * >          < * >                                   |" << endl;
	outfile << "|         |  (      \/             \/                                    |" << endl;
	outfile << "|          \   \            ^                                            |" << endl;
	outfile << "|           \   \         < * >                                          |" << endl;
	outfile << "|            \   \          \/                                           |" << endl;
	outfile << "|             ------                                                     |" << endl;
	outfile << "|________________________________________________________________________|" << endl;
	outfile << "|                                                                        |" << endl;
	outfile << "|                                                                        |" << endl;
	outfile << "|                                                                        |" << endl;
	outfile << "|                                                                        |" << endl;
	outfile << "|                                                                        |" << endl;
	outfile << "|                                                                        |" << endl;
	outfile << "|                                                                        |" << endl;
	outfile << "|                                                                        |" << endl;
	outfile << "|________________________________________________________________________|" << endl;

	//closing files
	infile.close();
	outfile.close();
	return 0;
}