﻿/*
Name: Heba A
Date: 8/28/18
Description: Calculates profit of selling/exporting tropical fruits grown in the Bahamas based on selling price of fruit,
how much workers are paid, and the price of tariffs
*/

#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int main()
{
	//variables
	ifstream inFile;
	ofstream outFile;
	//fruit prices
	double banana = 0.0;
	double coconut = 0.0;
	double grapefruit = 0.0;
	double mango = 0.0;
	double pineapple = 0.0;

	double tariff = 0.0;
	double employeePay = 0.0;
	//Number of fruits sold
	double bananaNum = 0.0;
	double coconutNum = 0.0;
	double grapefruitNum = 0.0;
	double mangoNum = 0.0;
	double pineappleNum = 0.0;
	//Gross income of each fruit
	double totalBanana = 0.0;
	double totalCoconut = 0.0;
	double totalGrapefruit = 0.0;
	double totalMango = 0.0;
	double totalPineapple = 0.0;

	double grossIncome = 0.0;
	double netIncome = 0.0;
	double yearlyIncome = 0.0;



	inFile.open("‪C:/Users/alsousi736/Desktop/prices.txt");
	outFile.open("‪C:/Users/halsousi736/Desktop/endResult.out");

	//takes variable value from file
	inFile >> banana;
	inFile >> coconut;
	inFile >> grapefruit;
	inFile >> mango;
	inFile >> pineapple;

	cout << "Enter how much money goes to your employees monthly: ";
	cin >> employeePay;

	cout << "Enter how much you spend on tariffs: ";
	cin >> tariff;

	cout << "Enter how many bananas you sell monthly on average: ";
	cin >> bananaNum;

	cout << "Enter how many coconuts you sell monthly on average: ";
	cin >> coconutNum;

	cout << "Enter how many grapefruits you sell monthly on average: ";
	cin >> grapefruitNum;

	cout << "Enter how many mangos you sell monthly on average: ";
	cin >> mangoNum;

	cout << "Enter how many pineapples you sell monthly on average: ";
	cin >> pineappleNum;

	//calculates the gross income of each fruit
	totalBanana = banana * bananaNum;
	totalCoconut = coconut * coconutNum;
	totalGrapefruit = grapefruit * grapefruitNum;
	totalMango = mango * mangoNum;
	totalPineapple = pineapple * pineappleNum;

	grossIncome = (totalBanana + totalCoconut + totalGrapefruit + totalMango + totalPineapple);
	netIncome = (grossIncome - tariff - employeePay);
	yearlyIncome = netIncome * 12;

	outFile << "Your monthly profit is equal to: " << netIncome
		<< " Your yearly profit is equal to: " << yearlyIncome;



	inFile.close();
	outFile.close();
	return 0;
}
