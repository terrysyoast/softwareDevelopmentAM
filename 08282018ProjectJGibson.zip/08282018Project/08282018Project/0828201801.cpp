/*
Name: Justice Gibson
Date: 8.28.18
Description: Find your tax rate in Singapore
*/

#include <iostream>
#include <iomanip>
#include <fstream>

using namespace std;

int main()
{
	//variables
	ifstream inFile;
	ofstream outFile;
	
	double basetax = 0;
	double money = 0.0;

	//initalize outfile and infile, and then formatting the outfile.
	inFile.open("C:/Users/Jgibson256/Desktop/Singapore Money.txt");
	outFile.open("C:/Users/Jgibson256/Desktop/Singapore Tax File.txt");
	outFile << fixed << showpoint;
	outFile << setprecision(2);

	cout << "Processing...";
	//Confirm what the money is and send it to the if statements.
	inFile >> money;

	//Using the money from the file, find the tax rate from Singapore that fits the money, going from 22% to 0%.
	if (money > 320000)
		//if money is above 320,000, the tax rate should be 22%
		basetax = 22;
	else
		if (280000 < money && money < 320000.01)
			//if money is between 280,000 and 320,000, the tax rate should be 20%
			basetax = 20;
		else
			if (240000 < money && money < 280000.01)
				//if money is between 240,000 and 280,000, the tax rate should be 19.5%
				basetax = 19.5;
			else
				if (200000 < money && money < 240000.01)
					//if money is between 200,000 and 240,000, the tax rate should be 19%
					basetax = 19;
				else
					if (160000 < money && money < 200000.01)
						//if money is between 160,000 and 200,000, the tax rate should be 18%
						basetax = 18;
					else
						if (120000 < money && money < 160000.01)
							//if money is between 120,000 and 160,000, the tax rate should be 15%
							basetax = 15;
						else
							if (80000 < money && money < 120000.01)
								//if money is between 80,000 and 120,000, the tax rate should be 11.5%
								basetax = 11.5;
							else
								if (40000 < money && money < 80000.01)
									//if money is between 40,000 and 80,000, the tax rate should be 7%
									basetax = 7;
								else
									if (30000 < money && money < 40000.01)
										//if money is between 30,000 and 40,000, the tax rate should be 3.5%
										basetax = 3.5;
									else
										if (20000 < money && money < 30000.01)
											//if money is between 20,000 and 30,000, the tax rate should be 2%
											basetax = 2;
										else
											if (money < 20000.01)
												//if money is under 20,000, there should be no tax rate.
												basetax = 0;
											else
												//If they add something else other than a number, tell them of the error.
												cout << "Error! you did not enter the money correctly!";
	
	//send it into the outFile, telling them the confirmed tax rate
	outFile << "Your personal tax rate in Singapore would be " << basetax << "%!";
	
	//close both of the files.
	inFile.close();
	outFile.close();

	//end the program.
	return 0;
}