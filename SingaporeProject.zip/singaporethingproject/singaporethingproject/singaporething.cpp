/*
Name:  Cameron Snow
Date:  08/28/18
Description:  Singapore File Project
*/

#include <iostream>
#include <iomanip>
#include <fstream>
using namespace std;

int main()
{
	//variables
	double baseTax = 0.0;
	double money = 0.0;
	int hold;
	ifstream inFile;
	ofstream outFile;

	//initialize outfile
	inFile.open("C:/Users/csnow836/Desktop/SingaporeMoney.txt");  //open the input file
	outFile.open("C:/Users/csnow836/Desktop/SingaporeTax.txt");  //open the output file
	outFile << fixed << showpoint;
	outFile << setprecision(2);  //set it to 2 decimal points
	//ask for the money
	cout << "How much money do you make? " << endl;  //put any number (preferably a large number in the hundred thousands)
	inFile >> money;	//store your input in the money variable

	cout << "Processing data... " << endl << endl;

	//end of couts
	if (money > 320000.00)  //if your amount of money is greater than 320000.00
		baseTax = 22;		//then you have 22% tax rate
	else
		if (280000.00 < money && money < 320000.00)  //if you make between 280000 and 320000
			baseTax = 20;							 //your tax rate is 20%
		else
			if (240000.00 < money && money < 280000.00)		//same thing over and over with different percents
				baseTax = 19.5;
			else
				if (200000.00 < money && money < 240000.00)
					baseTax = 19;
				else
					if (160000.00 < money && money < 200000.00)
						baseTax = 18;
					else
						if (120000.00 < money && money < 160000.00)
							baseTax = 15;
						else
							if (80000.00 < money && money < 120000.00)
								baseTax = 11.5;
							else
								if (40000.00 < money && money < 80000.00)
									baseTax = 7;
								else
									if (30000.00 < money && money < 40000.00)
										baseTax = 3.5;
									else
										if (20000.00 < money && money < 30000.00)
											baseTax = 2;
										else
											if (0.00 < money && money < 20000.00)
												baseTax = 0;
	outFile << "Your personal tax rate in Singapore would be " << baseTax << " %";  //plug in the tax rate according to the amt. of money you put
	outFile.close();  //close the outfile
	return 0;
}