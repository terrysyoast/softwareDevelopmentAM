/*
name: Lura and William
date: 08/28/18
description:
*/

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

int main()
{
	//variables
	int hold;
	ifstream infile;
	ofstream outfile;

	double day1 = 0.0, day2 = 0.0, day3 = 0.0, day4 = 0.0, day5 = 0.0;
	double average = 0.0;
	double total = 0.0;
	
	/*the point of the point is to point to the file to be used 
	(simply reads data of the input file and moves it into the code and then out into the output file)*/
	infile.open("C:/Users/lrider825/Desktop/moneySpent.txt");
	outfile.open("C:/Users/lrider825/Desktop/totalMoney.out");

	//allows the answer go to 2 decimal points for sake of precision
	outfile << fixed << showpoint;
	outfile << setprecision(2);

	infile >> day1 >> day2 >> day3
		>> day4 >> day5;

	//tells you how much money was spent for each day
	outfile << "Money spent each day: " << setw(8) << day1
		<< setw(8) << day2 << setw(8) << day3
		<< setw(8) << day4 << setw(8) << day5
		<< endl;

	//calculates total
	total = (day1 + day2 + day3 + day4 + day5);
	
	//shows total
	outfile << "total money spent: " << setw(8)
		<< total << endl;

	//calculates average
	average = (day1 + day2 + day3 + day4 + day5) / 5.0;

	//shows average
	outfile << "Average amount spent perday: " << setw(8)
		<< average << endl;

	infile.close();
	outfile.close();


	return 0;
}