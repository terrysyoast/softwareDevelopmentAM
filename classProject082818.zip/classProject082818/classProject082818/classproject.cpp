/*
Name:		Kevin Pagan
			Anna Crook
Date:		08.28.2018
Description:Tells popular tourist spots in the U.A.E
*/

#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>

using namespace std;

int main() {
	ifstream inFile;
	ofstream outFile;


	//variables
	int hold = 0;
	string one = " ";
	string two = " ";
	string three = " ";
	string four = " ";
	string five = " ";


	//opens file with tourist attractions
	inFile.open("C:/Users/Kpaganmaisonet346/Documents/UAEproject.txt");
	outFile.open("C:/Users/Kpaganmaisonet346/Documents/UAEproject.out");

	//inputs the strings into the variables
	inFile >> one >> two >> three >> four >> five;


	//removes the underscore
	int a = 0;
	string touristArray[5] = {one, two, three, four, five};
	string curString = " ";
	char x = '_';
	//while loop to check through all the tourist spots
	while (a < 5) {
		curString = touristArray[a];
		//checks through each character and replaces the underscores to be just spaces
		for (int i = 0; i < curString.length(); i++) {
			if (x == curString[i]) {
				curString[i] = ' ';
				touristArray[a] = curString;
			}
		}
		//replaces each string to the new strings with spaces
		one = touristArray[0];
		two = touristArray[1];
		three = touristArray[2];
		four = touristArray[3];
		five = touristArray[4];
		a++;
	}



	//outputs the tourist attraction on screen
	outFile << "The top 5 tourist atractions in the U.A.E are " << endl;
	outFile << "1 " << one << endl;
	outFile << "2 " << two << endl;
	outFile << "3 " << three << endl;
	outFile << "4 " << four << endl;
	outFile << "5 " << five << endl;

	//holds the screen in place for reading
	cin >> hold;
	return 0;
}