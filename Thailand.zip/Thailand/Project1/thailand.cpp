﻿/*
Names: Alex and Annie
Date: 08.28.2018
Description: Thailand Fun Fact Quiz
*/

#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>

using namespace std;

int main()
{
	int score = 0;

	ifstream inFile;
	ofstream outFile;

	string firstName = " ";
	string lastName = " ";

	string ans1 = " ";
	string ans2 = " ";
	string ans3 = " ";
	string ans4 = " ";
	string ans5 = " ";
	string ans6 = " ";
	string ans7 = " ";
	string ans8 = " ";
	string ans9 = " ";
	string ans10 = " ";
	string rightAns1 = " ";
	string rightAns2 = " ";
	string rightAns3 = " ";
	string rightAns4 = " ";
	string rightAns5 = " ";
	string rightAns6 = " ";
	string rightAns7 = " ";
	string rightAns8 = " ";
	string rightAns9 = " ";
	string rightAns10 = " ";

	cout << "This is the Thailand Fun Fact True or False Quiz!" << endl;

	cout << "Enter your first name ";
	cin >> firstName;
	cout << endl;

	cout << "Enter your last name ";
	cin >> lastName;
	cout << endl;

	cout << "true or false: Thailand's name means 'Land of the Free' ";
	cin >> ans1;
	cout << endl;

	cout << "true or false: Russia borders Thailand ";
	cin >> ans2;
	cout << endl;

	cout << "true or false: Thailand has the world's largest crocodile farm ";
	cin >> ans3;
	cout << endl;

	cout << "true or false: Buddhism is Thailand's largest religion ";
	cin >> ans4;
	cout << endl;

	cout << "true or false: The world's biggest mammal is found in Thailand ";
	cin >> ans5;
	cout << endl;

	cout << "true or false: Thailand is the world's 20th largest country ";
	cin >> ans6;
	cout << endl;

	cout << "true or false: 75% of Thailand's population is Chinese ";
	cin >> ans7;
	cout << endl;

	cout << "true or false: Thailand's national language is called Thai ";
	cin >> ans8;
	cout << endl;

	cout << "true or false: Siamese cats are not native to Thailand, but a large percentage of them live in Thailand ";
	cin >> ans9;
	cout << endl;

	cout << "true or false: Traffic police in Thailand wear facemasks because of air pollution ";
	cin >> ans10;
	cout << endl;

	inFile.open("C:/Users/afitzmaurice625/Desktop/ThailandIn.txt");
	outFile.open("C:/Users/afitzmaurice625/Desktop/ThailandOut.out");

	inFile >> rightAns1 >> rightAns2 >> rightAns3
		>> rightAns4 >> rightAns5 >> rightAns6
		>> rightAns7 >> rightAns8 >> rightAns9 >> rightAns10;

	if (ans1 == rightAns1)
	{
		score++;
	}
	if (ans2 == rightAns2)
	{
		score++;
	}
	if (ans2 == rightAns2)
	{
		score++;
	}
	if (ans3 == rightAns3)
	{
		score++;
	}
	if (ans3 == rightAns3)
	{
		score++;
		cout << "Correct" << endl;
	}
	if (ans4 == rightAns4)
	{
		score++;
	}
	if (ans5 == rightAns5)
	{
		score++;
	}
	if (ans6 == rightAns6)
	{
		score++;
	}
	if (ans7 == rightAns7)
	{
		score++;
		cout << "Correct" << endl;
	}
	if (ans8 == rightAns8)
	{
		score++;
	}
	if (ans9 == rightAns9)
	{
		score++;
	}
	if (ans10 == rightAns10)
	{
		score++;
		cout << "Correct" << endl;
	}

	outFile << firstName << " " << lastName << endl;
	outFile << "Your Score: " << score;

	inFile.close();
	outFile.close();

	return 0;
}
