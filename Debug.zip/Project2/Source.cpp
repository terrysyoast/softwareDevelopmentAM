/*
name william mayfield
date 08.28.2018
description test avg
*/

#include<iostream>
#include<fstream>
#include<iomanip>

using namespace std;

int main()
{
	// varibles 
	int hold;
	ifstream infile;
	ofstream outfile;

	double day1 = 0.0, day2 = 0.0, day3 = 0.0, day4 = 0.0, day5 = 0.0;
	double average = 0.0;
	double total = 0.0;
	// where the files n=come in the code
	infile.open("C:/Users/wmayfield929/Desktop/spend.txt");
	outfile.open("C:/Users/wmayfield929/Desktop/total.txt");

	outfile << fixed << showpoint;
	outfile << setprecision(2);
	// file grabing the days 
	infile >> day1 >> day2 >> day3 >> day4 >> day5;

	outfile << "money spent per day: " << setw(10) << day1
		<< setw(10) << day2 << setw(10) << day3
		<< setw(10) << day4 << setw(10) << day5
		<< endl;
	// adding the money toghter 
	total = (day1 + day2 + day3 + day4 + day5);

	outfile << "total money spent: " << setw(10)
		<< total << endl;
	// finding the avg
	average = (day1 + day2 + day3 + day4 + day5) / 5.0;

	outfile << "average money spent perday: " << setw(10)
		<< average << endl;



	infile.close();
	outfile.close();


	return 0;







}
